"""
document_extraction Lambda function.

First stage of the AI pipeline. Every one of the four SOW agents consumes the
text this function produces, so nothing downstream runs until this succeeds.

Trigger:
    SQS event (from the S3 upload notification on the landing zone bucket),
    matching the pattern already used by data_processor.

Batches:
    The queue hands this function up to 10 uploads at once. Each message is
    processed independently and in parallel - BDA jobs are asynchronous, so ten
    documents take about as long as one and stay well inside the timeout. If
    any message fails, the ones that succeeded are deleted from the queue before
    the invocation fails, so only the failed uploads are retried and, after
    three attempts, reach the dead letter queue. Without that, one bad file
    would send every document in its batch round again (repeat BDA jobs and
    repeat agent runs) and take them all to the DLQ with it. This works whether
    or not the event source mapping reports partial batch failures.

Flow:
    1. Resolve the uploaded S3 object to a row in app.contracts
    2. Insert a judy_ai.document_extractions row (status 'running') immediately,
       recording the BDA invocation ARN before we wait on anything
    3. Invoke Bedrock Data Automation asynchronously
    4. Wait for BDA to finish, bounded by MAX_WAIT_SECONDS
    5. Read the BDA output from S3, normalize it to plain text
    6. Store the text and mark the extraction 'succeeded'
    7. Fire the three pre-signing agents asynchronously

The SOW mandates Bedrock Data Automation for text extraction:
    "The team will use bedrock data automation to extract text from PDF and
     Word formats. Document parsing failures are put into a dead letter queue
     for manual resolution by customer."

Why we wait inline instead of polling on a schedule:
    BDA is asynchronous. data_processor solves the equivalent problem for KB
    ingestion with an EventBridge Scheduler plus a second Lambda. That machinery
    is worth it for jobs that run for many minutes; for a document capped by the
    SOW at 20 pages / 10 MB, BDA normally finishes well inside a single
    invocation, so a bounded inline wait keeps this to one function and one IAM
    role.

    This is safe to time out. The extraction row is written with its invocation
    ARN *before* the wait starts, so a slow job leaves a 'running' row that can
    be reconciled later rather than being lost. If BDA turns out to be slow in
    practice, switch step 4 to a BDA EventBridge completion notification without
    touching anything else in this file.
"""

import json
import os
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import unquote_plus

import boto3
from botocore.exceptions import ClientError

# --- Clients (boto3 clients are thread-safe) ---
bda_runtime_client = boto3.client("bedrock-data-automation-runtime")
s3_client = boto3.client("s3")
rds_data_client = boto3.client("rds-data")
lambda_client = boto3.client("lambda")
sqs_client = boto3.client("sqs")

# --- Environment Variables ---
AURORA_CLUSTER_ARN = os.environ["AURORA_CLUSTER_ARN"]
AURORA_SECRET_ARN = os.environ["AURORA_SECRET_ARN"]
AURORA_DATABASE = os.environ["AURORA_DATABASE"]
BDA_PROJECT_ARN = os.environ["BDA_PROJECT_ARN"]
BDA_PROFILE_ARN = os.environ["BDA_PROFILE_ARN"]
BDA_OUTPUT_BUCKET = os.environ["BDA_OUTPUT_BUCKET"]
BDA_OUTPUT_PREFIX = os.environ.get("BDA_OUTPUT_PREFIX", "bda-output")

# Comma-separated ARNs of the three pre-signing agent functions. Optional so
# this Lambda can be deployed and exercised before the agents exist.
PRE_SIGNING_AGENT_ARNS = [
    arn.strip()
    for arn in os.environ.get("PRE_SIGNING_AGENT_ARNS", "").split(",")
    if arn.strip()
]

MAX_WAIT_SECONDS = int(os.environ.get("MAX_WAIT_SECONDS", "240"))
POLL_INTERVAL_SECONDS = int(os.environ.get("POLL_INTERVAL_SECONDS", "5"))

# Documents of one batch processed at the same time. The SQS batch size is 10.
MAX_PARALLEL_DOCUMENTS = int(os.environ.get("MAX_PARALLEL_DOCUMENTS", "10"))


# =============================================================
# Aurora helpers (RDS Data API)
# =============================================================
# The Data API is used rather than a direct Postgres connection so this Lambda
# does not need VPC configuration. Every statement is parameterized - S3 keys
# and file names originate from user uploads and must never be interpolated
# into SQL.
def execute_sql(sql, parameters=None):
    """Run a parameterized statement against Aurora and return its records."""
    result = rds_data_client.execute_statement(
        resourceArn=AURORA_CLUSTER_ARN,
        secretArn=AURORA_SECRET_ARN,
        database=AURORA_DATABASE,
        sql=sql,
        parameters=parameters or [],
    )
    return result.get("records", [])


def string_param(name, value):
    """Build a Data API string parameter, mapping None to SQL NULL."""
    if value is None:
        return {"name": name, "value": {"isNull": True}}
    return {"name": name, "value": {"stringValue": str(value)}}


def long_param(name, value):
    """Build a Data API integer parameter, mapping None to SQL NULL."""
    if value is None:
        return {"name": name, "value": {"isNull": True}}
    return {"name": name, "value": {"longValue": int(value)}}


def resolve_contract_id(bucket, key):
    """
    Find the app.contracts row for an uploaded object.

    The application creates this row at upload time. If it is missing we do not
    invent one - contracts is app-owned, and silently creating rows here would
    hide an upload bug behind a successful-looking extraction.
    """
    records = execute_sql(
        "SELECT id::text FROM app.contracts WHERE s3_bucket = :bucket AND s3_key = :key",
        [string_param("bucket", bucket), string_param("key", key)],
    )
    if not records:
        return None
    return records[0][0]["stringValue"]


def create_extraction(contract_id, invocation_arn):
    """Insert a 'running' extraction row and return its id."""
    records = execute_sql(
        """
        INSERT INTO judy_ai.document_extractions
            (contract_id, bda_invocation_arn, status)
        VALUES
            (:contract_id::uuid, :invocation_arn, 'running')
        RETURNING id::text
        """,
        [
            string_param("contract_id", contract_id),
            string_param("invocation_arn", invocation_arn),
        ],
    )
    return records[0][0]["stringValue"]


def complete_extraction(extraction_id, text, page_count, output_s3_key):
    """Mark an extraction succeeded and store the normalized text."""
    execute_sql(
        """
        UPDATE judy_ai.document_extractions
           SET status            = 'succeeded',
               extracted_text    = :text,
               page_count        = :page_count,
               char_count        = :char_count,
               raw_output_s3_key = :raw_key,
               completed_at      = now()
         WHERE id = :id::uuid
        """,
        [
            string_param("id", extraction_id),
            string_param("text", text),
            long_param("page_count", page_count),
            long_param("char_count", len(text)),
            string_param("raw_key", output_s3_key),
        ],
    )


def fail_extraction(extraction_id, error_message):
    """Mark an extraction failed. Truncated to keep one bad document from bloating the row."""
    execute_sql(
        """
        UPDATE judy_ai.document_extractions
           SET status        = 'failed',
               error_message = :error,
               completed_at  = now()
         WHERE id = :id::uuid
        """,
        [
            string_param("id", extraction_id),
            string_param("error", error_message[:2000]),
        ],
    )


# =============================================================
# Bedrock Data Automation
# =============================================================
def invoke_bda(bucket, key):
    """Start an asynchronous BDA job and return its invocation ARN."""
    output_prefix = f"s3://{BDA_OUTPUT_BUCKET}/{BDA_OUTPUT_PREFIX}"

    response = bda_runtime_client.invoke_data_automation_async(
        inputConfiguration={"s3Uri": f"s3://{bucket}/{key}"},
        outputConfiguration={"s3Uri": output_prefix},
        dataAutomationConfiguration={
            "dataAutomationProjectArn": BDA_PROJECT_ARN,
            "stage": "LIVE",
        },
        dataAutomationProfileArn=BDA_PROFILE_ARN,
    )

    invocation_arn = response["invocationArn"]
    print(f"BDA invocation started: {invocation_arn} for s3://{bucket}/{key}")
    return invocation_arn


def wait_for_bda(invocation_arn):
    """
    Poll BDA until it reaches a terminal state or MAX_WAIT_SECONDS elapses.

    Returns (status, output_s3_uri, error_message). A timeout returns status
    'InProgress' with no output, which the caller treats as "leave the row
    running" rather than as a failure.
    """
    deadline = time.time() + MAX_WAIT_SECONDS

    while time.time() < deadline:
        status_response = bda_runtime_client.get_data_automation_status(
            invocationArn=invocation_arn
        )
        status = status_response["status"]

        if status == "Success":
            output_uri = status_response.get("outputConfiguration", {}).get("s3Uri")
            print(f"BDA succeeded: {invocation_arn} -> {output_uri}")
            return status, output_uri, None

        if status in ("ServiceError", "ClientError"):
            error_message = status_response.get("errorMessage", status)
            print(f"BDA failed ({status}): {error_message}")
            return status, None, error_message

        time.sleep(POLL_INTERVAL_SECONDS)

    print(f"BDA still running after {MAX_WAIT_SECONDS}s: {invocation_arn}")
    return "InProgress", None, None


def read_s3_json(s3_uri):
    """Read and parse a JSON object identified by an s3:// URI."""
    without_scheme = s3_uri.replace("s3://", "", 1)
    bucket, _, key = without_scheme.partition("/")
    body = s3_client.get_object(Bucket=bucket, Key=key)["Body"].read()
    return json.loads(body), bucket, key


def standard_output_paths(job_metadata):
    """Resolve job_metadata.json to the standard output documents it points at."""
    paths = []
    for segment in job_metadata.get("output_metadata", []):
        for asset in segment.get("segment_metadata", []):
            path = asset.get("standard_output_path")
            if path:
                paths.append(path)
    return paths


def page_markdown(document):
    """
    Join a BDA standard output document into text, in page order.

    Only pages[] is read, deliberately. BDA returns the same content twice:
    once as whole-page markdown in pages[], and again split per element in
    elements[]. Walking the structure generically collects both - on a real
    5-page advisor agreement that produced 31,008 characters against an actual
    15,527, with every sentence duplicated.

    Page markdown also preserves tables as markdown pipe tables, which matters
    because commission schedules, renewal windows and payment terms tend to
    live in tables, and those are exactly what the risk and obligation agents
    need to read.
    """
    pages = sorted(document.get("pages", []), key=lambda page: page.get("page_index", 0))

    blocks = []
    for page in pages:
        markdown = (page.get("representation") or {}).get("markdown")
        if isinstance(markdown, str) and markdown.strip():
            # Page markers let the agents cite a page number on every finding.
            # Without them the joined text has no page boundaries, and
            # source_page on contract_risks / contract_obligations could never
            # be populated - which is what makes manual review practical.
            blocks.append(f"[page {page.get('page_index', 0) + 1}]\n{markdown.strip()}")

    if blocks:
        return "\n\n".join(blocks)

    # Fallback for a result with no pages[]: use elements in reading order.
    # Not expected for DOCX or PDF, but preferable to returning nothing.
    elements = sorted(
        document.get("elements", []), key=lambda el: el.get("reading_order", 0)
    )
    element_blocks = [
        (el.get("representation") or {}).get("markdown", "").strip()
        for el in elements
    ]
    return "\n\n".join(block for block in element_blocks if block)


def count_pages(document):
    """Page count from BDA output metadata, falling back to the pages array."""
    metadata = document.get("metadata") or {}
    if isinstance(metadata.get("number_of_pages"), int):
        return metadata["number_of_pages"]

    pages = document.get("pages")
    return len(pages) if isinstance(pages, list) else 0


def extract_text_from_bda_output(output_s3_uri):
    """
    Read BDA's output and normalize it to plain text.

    Structure, verified against real BDA output from this account:

        job_metadata.json
          └─ output_metadata[].segment_metadata[].standard_output_path
               └─ result.json
                    ├─ metadata.number_of_pages
                    ├─ pages[].representation.markdown    <- used
                    └─ elements[].representation.markdown <- same text again

    Returns (text, page_count, output_s3_key).
    """
    job_metadata, _, metadata_key = read_s3_json(output_s3_uri)

    paths = standard_output_paths(job_metadata)
    if not paths:
        raise RuntimeError(f"No standard_output_path in BDA job metadata: {output_s3_uri}")

    blocks = []
    page_count = 0
    last_key = metadata_key

    for path in paths:
        document, _, key = read_s3_json(path)
        last_key = key
        page_count += count_pages(document)
        text = page_markdown(document)
        if text:
            blocks.append(text)

    return "\n\n".join(blocks), page_count, last_key


# =============================================================
# Downstream agents
# =============================================================
def trigger_pre_signing_agents(contract_id, extraction_id):
    """
    Fire the three pre-signing agents asynchronously.

    Invoked with InvocationType='Event' so extraction is not blocked by agent
    runtime, and so one failing agent cannot fail the others or this function.
    """
    if not PRE_SIGNING_AGENT_ARNS:
        print("No pre-signing agent ARNs configured yet - skipping downstream trigger")
        return

    payload = json.dumps({"contract_id": contract_id, "extraction_id": extraction_id})

    for arn in PRE_SIGNING_AGENT_ARNS:
        try:
            lambda_client.invoke(
                FunctionName=arn,
                InvocationType="Event",
                Payload=payload,
            )
            print(f"Triggered agent: {arn}")
        except ClientError as e:
            # Deliberately swallowed: extraction has already succeeded and is
            # persisted. A failed trigger is recoverable by re-running analysis
            # through the API; failing here would discard good extracted text.
            print(f"Failed to trigger agent {arn}: {e}")


# =============================================================
# Pipeline
# =============================================================
def process_document(bucket, key):
    """Run the full extraction pipeline for one uploaded object."""
    print(f"Processing s3://{bucket}/{key}")

    contract_id = resolve_contract_id(bucket, key)
    if contract_id is None:
        # Raising sends the SQS message to the DLQ, which is what the SOW asks
        # for: parsing problems surface for manual resolution rather than being
        # silently dropped.
        raise RuntimeError(
            f"No app.contracts row for s3://{bucket}/{key} - "
            "the application must create the contract record at upload time"
        )

    invocation_arn = invoke_bda(bucket, key)
    extraction_id = create_extraction(contract_id, invocation_arn)
    print(f"Extraction {extraction_id} created for contract {contract_id}")

    status, output_uri, error_message = wait_for_bda(invocation_arn)

    if status == "InProgress":
        # Left deliberately as 'running' with its invocation ARN recorded.
        print(f"Extraction {extraction_id} left running for later reconciliation")
        return

    if status != "Success":
        fail_extraction(extraction_id, error_message or f"BDA returned {status}")
        raise RuntimeError(f"BDA extraction failed for s3://{bucket}/{key}: {error_message}")

    text, page_count, output_key = extract_text_from_bda_output(output_uri)

    if not text.strip():
        fail_extraction(extraction_id, "BDA returned no extractable text")
        raise RuntimeError(f"No extractable text in s3://{bucket}/{key}")

    complete_extraction(extraction_id, text, page_count, output_key)
    print(
        f"Extraction {extraction_id} succeeded: "
        f"{page_count} pages, {len(text)} characters"
    )

    trigger_pre_signing_agents(contract_id, extraction_id)


def objects_in_record(record):
    """
    Return [(bucket, key)] for the S3 object notification(s) in one event record.

    The upload prefix already feeds the ingestion queue, so this function is
    fed by fan-out: S3 -> SNS -> its own SQS queue (Andres, 2026-09-22). That
    means each SQS record body is an SNS envelope whose "Message" field holds
    the S3 event as a JSON string - unless the subscription has raw message
    delivery on, in which case the body is the S3 event itself. Both shapes
    are accepted, as are a bare S3 event and a direct SNS invocation, so the
    handler does not depend on which option the IaC ends up with.

    An unrecognised body is logged and skipped, never silently ignored: a
    silent skip here would look exactly like "the upload never happened".
    """
    source = record.get("eventSource") or record.get("EventSource") or ""

    if source == "aws:s3" and "s3" in record:
        payloads = [{"Records": [record]}]
    elif source == "aws:sns":
        payloads = [json.loads(record["Sns"]["Message"])]
    else:
        body = record.get("body")
        try:
            payload = json.loads(body) if isinstance(body, str) else (body or {})
        except json.JSONDecodeError:
            print(f"Skipping record with non-JSON body: {str(body)[:200]}")
            return []
        if payload.get("Type") == "Notification" and "Message" in payload:
            try:
                payload = json.loads(payload["Message"])
            except (json.JSONDecodeError, TypeError):
                print(f"Skipping SNS envelope with non-JSON Message: {str(payload.get('Message'))[:200]}")
                return []
        payloads = [payload]

    objects = []
    for payload in payloads:
        s3_records = payload.get("Records") if isinstance(payload, dict) else None
        if not s3_records:
            # S3 also sends a one-off {"Event": "s3:TestEvent"} when a
            # notification is first configured. Log and move on.
            print(f"Record carries no S3 object notification - skipping: {json.dumps(payload)[:200]}")
            continue
        for s3_record in s3_records:
            s3_info = s3_record.get("s3") or {}
            bucket = (s3_info.get("bucket") or {}).get("name")
            raw_key = (s3_info.get("object") or {}).get("key")
            if not bucket or not raw_key:
                print(f"S3 record missing bucket or key - skipping: {json.dumps(s3_record)[:200]}")
                continue
            # S3 event keys are URL-encoded; file names in this project
            # contain spaces (for example "Mutual NDA_Template.docx").
            objects.append((bucket, unquote_plus(raw_key)))
    return objects


def s3_objects_in(event):
    """Yield (bucket, key) for every S3 object notification in an event."""
    for record in event.get("Records", []):
        yield from objects_in_record(record)


def queue_url_from_arn(queue_arn):
    """arn:aws:sqs:<region>:<account>:<name> -> the queue URL (no GetQueueUrl permission needed)."""
    _, _, _, region, account, name = queue_arn.split(":", 5)
    return f"https://sqs.{region}.amazonaws.com/{account}/{name}"


def is_sqs_message(record):
    return record.get("eventSource") == "aws:sqs" and "receiptHandle" in record


def run_record(record):
    """
    Process every document in one event record. Never raises: returns the
    number of documents processed and the error, if any, so one failure cannot
    stop the rest of the batch.
    """
    try:
        count = 0
        for bucket, key in objects_in_record(record):
            process_document(bucket, key)
            count += 1
        return count, None
    except Exception as e:  # noqa: BLE001 - reported per record, re-raised by the handler
        traceback.print_exc()
        return 0, e


def delete_from_queue(record):
    """Remove a successfully processed message so a failed batch does not retry it."""
    try:
        sqs_client.delete_message(
            QueueUrl=queue_url_from_arn(record["eventSourceARN"]),
            ReceiptHandle=record["receiptHandle"],
        )
        return True
    except ClientError as e:
        # Not fatal: the message comes back and the document is processed again.
        print(f"Could not delete processed message {record.get('messageId')}: {e}")
        return False


def lambda_handler(event, context):
    """Entry point. Handles S3 upload notifications, via SQS/SNS fan-out or direct."""
    print(f"Event received: {json.dumps(event)[:500]}")

    records = event.get("Records", [])
    if not records:
        print("No records in event")
        return {"statusCode": 200, "body": "processed 0 document(s)"}

    # In parallel: each document spends most of its time waiting on BDA.
    with ThreadPoolExecutor(max_workers=max(1, min(len(records), MAX_PARALLEL_DOCUMENTS))) as pool:
        results = list(pool.map(run_record, records))

    processed = sum(count for count, _ in results)
    failed = [(record, error) for record, (_, error) in zip(records, results) if error is not None]

    if failed:
        # Delete the successes first, so raising retries only the failures.
        removed = sum(
            1 for record, (_, error) in zip(records, results)
            if error is None and is_sqs_message(record) and delete_from_queue(record)
        )
        ids = ", ".join(str(r.get("messageId") or "?") for r, _ in failed)
        raise RuntimeError(
            f"{len(failed)} of {len(records)} record(s) failed ({ids}); "
            f"{processed} document(s) processed, {removed} message(s) removed from the queue. "
            f"First error: {failed[0][1]}"
        )

    if processed == 0:
        print("No S3 object notifications in event")
    return {"statusCode": 200, "body": f"processed {processed} document(s)"}
